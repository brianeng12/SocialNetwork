# SocialNetwork

README

Course: cs400
Semester: Fall 2021
Project name: Social Network
Team Members:
1. Brian Eng, 010, and beng@wisc.edu
2. Ben Hutchison, 010, and bhutchison2@wisc.edu
3. Bill Johnson, 010, and wjohnson24@wisc.edu
4. Chris Lansford, 010, and lansford@wisc.edu

 
Which team members were on same xteam together?


Other notes or comments to the grader:

[place any comments or notes that will help the grader here]
