package application;

public class ManagerClass {
	public ManagerClass() {
		
	}
	
	
}
